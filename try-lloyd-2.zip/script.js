async function templatePostprocessing() {
    $('[type="list"] [type="list-row"]:first').css('color', 'red');
    $('[type="list"] [type="list-row"]:last').css('color', 'green');
}